﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FunkyCarApp
{
    public class GlobalInventory
    {
        public List<CarList> ListOfCarLists { get; set; } = new List<CarList>();
    }
}
